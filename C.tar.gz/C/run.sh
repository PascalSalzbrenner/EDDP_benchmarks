# cores read from input
cores=$1
timestep=2 #timestep in fs
temp=300 #temperature in K
vol=8000 #volume in A^3
num_steps=99 #number of steps

ramble -ompnp $cores -ts $timestep -dr 0 -tt $temp -v $vol -f -m $num_steps C 1> /dev/null 2> times-$cores.txt
grep "total  :" times-$cores.txt | awk -v cores="${cores}" '{print "cores="cores" "$3/800/100*1000 " ms/at"}' >> bench-out.txt
